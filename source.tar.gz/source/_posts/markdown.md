---
title: markdown语法小结
date: 2016-12-12 
categories:
- 知识总结
tags:
- markdown
---

### 1.标题
 ![](http://ou3jfk5zy.bkt.clouddn.com/markImg/1.png)
 
<!--more-->
### 2.列表
![列表](http://ou3jfk5zy.bkt.clouddn.com/markImg/2.png  "列表")
### 3.引用
![引用](http://ou3jfk5zy.bkt.clouddn.com/markImg/3.png  "引用")
### 4.代码块
![代码块](http://ou3jfk5zy.bkt.clouddn.com/markImg/9.png  "代码块")
### 5.粗体和斜体
![](http://ou3jfk5zy.bkt.clouddn.com/markImg/4.png) 
### 6.超链接
![](http://ou3jfk5zy.bkt.clouddn.com/markImg/5.png) 
### 7.分割线
![](http://ou3jfk5zy.bkt.clouddn.com/markImg/6.png) 
### 8.表格
![](http://ou3jfk5zy.bkt.clouddn.com/markImg/7.png) 
###  9.工具栏
![](http://ou3jfk5zy.bkt.clouddn.com/markImg/8.png) 
### 10.总结
![](http://ou3jfk5zy.bkt.clouddn.com/markImg/sum.png) 
