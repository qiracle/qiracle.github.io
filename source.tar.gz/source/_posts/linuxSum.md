---
title: Linux命令小结
date: 2016-12-16
categories:
- 知识总结
tags:
- Linux
---
#### cd
cd 进入某个目录

cd ~ 返回最初目录

cd - 返回上次目录

***
#### 文件
touch 1.txt 创建1.txt文件

cp 复制文件，格式：cp 源文件 目标文件
<!--more-->
mv 移动文件 格式如上

rm 删除文件 （rm 文件夹 -r 递归删除文件夹内所有内容，并删除文件夹）


***
#### 文件夹
mkdir 创建文件夹

rmdir 删除文件夹 文件夹有内容时不可删
***
####  ls
ls -alh 显示当前目录下所有文件并显示文件大小

ls 1* 显示所有文件名以1开头的文件

ls 1? 显示文件名只有两个字母且第一个字符为1的文件

ls >1.txt 重定向 将ls的内容显示在1.txt中

ls >>1.txt 将ls的内容追加在1.txt中

***

#### 查看cat、more
cat 1.txt 查看1.txt里的内容

more 1.txt 1.txt内容过多时，分页显示

***
#### 查找grep、find
grep -n  '123' ./1.txt 显示当前目录下1.txt里含有字符123所在的行，并显示其行号 （可用正则表达式表示）

find ./ -name 'qq*' 显示当前目录下文件名以qq的开头的文件

***
#### 软、硬链接ln
ln 1.txt link1.txt 给1.txt建立一个硬链接link1.txt 

ln -s 1.txt link1.txt 给1.txt建立一个软链接link1.txt

***
#### 系统集成ps、top、kill
ps 显示当前进程信息

top 动态显示显示当前系统进程信息

kill 根据进程id杀死进程

kill -9 强制杀死某进程

***
#### 解压打包
tar -zxvf FileName.tar 解压

tar -zcvf FileName.tar DirName 打包并压缩

***
#### 用户操作
useradd 用户名 -m

passwd

ssh user@ip地址

su 用户名 切到其他用户

cat /etc/group

groupmod tab*3

groupadd


groupdel
groups 用户名 查看所在组

usermod -a -G 组名 用户名 修改用户所在组。。必须在adm和sudo组的用户才能拥有root权限


***
#### 权限修改chmod 

a 所有的

u 当前用户

g 当前用户组

o 其他用户


r 读 w写 x执行


a+r 表示给所有用户增加读权限

a-r 表示给所有用户删除读权限

u+r 表示给当前用户增加读权限

u-r 表示给当前用户删除读权限

a=rw 给所有用户增加读写权限


其他以此类推

例子：chmod u+r,g+r,o+r 文件名 表示被所有用户增加读写可执行权限  与 chmod a+r 用户名 作用相同

权限表示：

1 执行

2 写

4 读

7=1+2+4表示可读可写可执行，类似的6=4+2可读可写，，以此类推


chmod 776 文件名 则表示当前用户和当前用户组拥有可读可写可执行权限，其他用户拥有可读可写权限


chown 用户 文件名 表示修改文件所有者

chgrp 用户组 文件名 表示修改用户所在用户组

***
#### vim

vim

i 命令模式进入编辑模式


shift+；进入末行模式


esc  返回上个模式


wq等价于x 保存并退出




