---
title: 初识github.io
date: 2016-12-09 
categories:
- 教程
tags:
- Hexo

---
　　很早之前就想用github搭建自己的blog，但之前由于比赛和找工作的事情一直没时间，其实是自己嫌麻烦吧。。第一次听说用github.io做个人博客时还是在半年之前在实验室看学弟在弄，当时心里还有点嘲笑他的，因为这个给我的印象就是在套网页模板，没啥技术含量，而不是我想的自己纯用手写代码做出的网站那样有逼格。直到后来看到越来越多的人都在用github.io搭个人博客，然后<!--more-->自己在google搜了一下，发现这个确实蛮有意思的。趁这段时间没啥事就自己搭个博客玩玩。
　　具体流程也网上有很多，大概就是先注册个github账号，然后安装hexo和node.js，然后github上建一个仓库名字必须是 你的用户名.github.io(如qiracle.github.io)。我的是在Linux下搭建的。hexo主要有三个命令需要记住：
　　hexo g ：这个命令是在public里生成网页文件
　　hexo d  :将博客部署到网站上，也就是将网页推送到了github上
　　hexo s ：启动本地服务器，这样就可以在浏览器中输入localhost:4000来访问。
　　
　　另外，我们可以下载各类主题放在theme文件夹下，然后修改config.yml,将里面的theme替换成你下载的主题主题名字就可以了。预览效果需要输入hexo g 和hexo d。然后浏览器中输入网址username.github.io就可以看到效果了，记得每次修改文件都需要在终端输入hexo g和hexo d。

