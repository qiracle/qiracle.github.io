---
title: 小记(一)
date: 2016-12-13 
categories:
- 生活感悟
tags:
- 随笔
---

做自己必须的要做事还是做自己喜欢的事，鱼和熊掌不可兼得
		for（day=start；；day++）｛
		doMymustTodoThings（）；
		knowledge++；
		experience++;
		happy--;
		if(i want）{
<!--more-->
		continue;
		}
		else{
		break;
		}
		}
		doMyLoveThings();
		happy++;
