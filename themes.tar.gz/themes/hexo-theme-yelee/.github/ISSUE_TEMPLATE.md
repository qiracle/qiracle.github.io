> 建议阅读：[在 Stack Overflow 提问的检查表](http://t.cn/R5tOIdv)
> Recommended Reading: [STACK OVERFLOW QUESTION CHECKLIST](http://tinyurl.com/stack-checklist)